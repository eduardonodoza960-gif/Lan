package com.example.lanlink;

import net.fabricmc.api.ClientModInitializer;

public class LanLinkClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        System.out.println("LanLink Client Initialized for 1.21.4");
    }
}
